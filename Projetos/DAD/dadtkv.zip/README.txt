How to run the projet?

To run our project you simply need to run Program.cs on ConfigScript/

Authors:
Guilherme Pascoal - 99079
José Cutileiro - 99097
Vasco Vás - 99133